#### OS (e.g. Windows 10 or macOS Sierra)

#### Versions of xlwings, Excel and Python (e.g. 0.11.8, Office 365, Python 3.7)

#### Describe your issue (incl. Traceback!)

```python
# Your traceback here

```

#### Include a minimal code sample to reproduce the issue (and attach a sample workbook if required!)

```python
# Your code here

```