#include <windows.h>
#include <sstream>
#include <fstream>
#include <tchar.h>
#include <unordered_map>
#include <unordered_set>

#include <algorithm> 
#include <functional> 
#include <cctype>
#include <locale>

#include "utils.h"
#include "dispatch.h"
#include "config.h"

extern HINSTANCE hInstanceDLL;