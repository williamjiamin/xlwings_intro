.. toctree::
    :maxdepth: 2
    :hidden:
    
    course
    migrate_to_0.11
    migrate_to_0.9
    installation
    quickstart
    connect_to_workbook
    syntax_overview
    datastructures
    addin
    vba
    udfs
    debugging
    matplotlib
    converters
    threading_and_multiprocessing
    command_line
    missing_features
    other_office_apps
    deployment
    extensions
    r_and_julia
    troubleshooting
    rest_api
    api
    license





