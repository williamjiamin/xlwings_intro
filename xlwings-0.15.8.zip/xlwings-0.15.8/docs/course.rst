Video course
============

Those who prefer a didactically structured video course over this documentation should have a look
at our video course:

https://training.zoomeranalytics.com/p/xlwings

It's also a great way to support the ongoing development of xlwings :)


